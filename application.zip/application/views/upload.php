<html>
<head>
<title>Hello There</title>
</head>
<body>
<?=form_open_multipart("Home/test")?>
<input type="file" name="userfile"/>
<input type="submit" value="Submit"/>
</form>
</body>
</html>